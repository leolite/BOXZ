Updated by Leo.Zhu 2013.04.27
1. Add support for Arduino 1.0+